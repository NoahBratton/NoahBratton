package brattonNoahInvestmentValue;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class BrattonNoahInvestmentValue extends Application {
			@Override
	public void start(Stage primaryStage) {
		try {
			HBox space = new HBox();
			space.setMinWidth(20);
			VBox root = new VBox(8);
			Scene scene = new Scene(root, 400, 400);
			// scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			root.setPadding(new Insets(20));
			Label investmentValue = new Label("Investment Amount");
			TextField investmentValueText = new TextField();
			investmentValueText.setMaxWidth(250);
			Label years = new Label("Years");
			TextField yearsText = new TextField();
			Label annualInterestRate = new Label("Annual Interest Rate");
			TextField annualInterestRateText = new TextField();
			Label futureValue = new Label("Future Value");

			Button calculateButton = new Button();
			VBox.setMargin(calculateButton, new Insets(20, 0, 0, 0));
			calculateButton.setText("Calculate");
			calculateButton.setOnAction(event -> {
				double investmentAmount = Double.parseDouble(investmentValueText.getText());
				double yearsAmount = Double.parseDouble(yearsText.getText());
				double annualInterestRateAmount = Double.parseDouble(annualInterestRateText.getText());
				double futureValueAmount = Math.pow((1 + ((annualInterestRateAmount/100)/12)),(yearsAmount * 12)) * investmentAmount;
				double temp = Math.round(futureValueAmount * 100)/100;
				System.out.println(temp);
				Text futureValueText = new Text(String.valueOf(temp));
				root.getChildren().add(futureValueText);
				//think about what youre trying to do to the original text what is it trying to its starting at 0.0 so what are you trying to do with that.
			});
			
			root.getChildren().addAll(investmentValue, investmentValueText, years, yearsText, annualInterestRate,
					annualInterestRateText, space, calculateButton, futureValue);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
